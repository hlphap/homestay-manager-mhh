const mongoose = require('mongoose')
const orderSchema = new mongoose.Schema({
    uname:{type: String, default:null},
    datein:{type: String, default:null}, 
    dateout:{type: String, default:null},
    phone:{type:String,default:null},
    room:{type:String,default:null}
  });
module.exports = mongoose.model('order', orderSchema);