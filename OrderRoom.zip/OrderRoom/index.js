const express = require("express");

require("./mongodb")

const bodyParser = require('body-parser')
let app = express();
const http = require("http").createServer(app);

const orderModel = require("./database/orderSchema")

const port = 3000;
const admincookie ="sadasdasdxgdtdx8wvie4yhiuyctiesuytinhbilabtabsyo8vnytdxtcbuzibeaw87vet78wayt";

app.set("views","views");
app.set('view engine', 'ejs');

app.use(express.static('public'))
app.use(bodyParser.json()) // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })) // for parsing application/x-www-form-urlencoded


http.listen(port,()=>{
    console.log("server is listening port 3000")
})

app.get("/",(req,res)=>{
    console.log(req.headers.cookie)
    res.render("index",{user:{name:"Nam", university:"UIT"}});
})
app.get("/login",(req,res)=>{
    res.render("login")
})
app.get("/showorders",async(req,res)=>{
    console.log(req.headers.cookie, "admin="+admincookie)
    if (req.headers.cookie == "admin="+admincookie)
    {
    let orders = await orderModel.find();
    res.render("showorders",{orders})
    }
    else res.redirect("/")
})
app.get("/create_account",(req,res)=>{
    res.render("create_account")
})
app.get("/order_room",(req,res)=>{
    res.render("order_room")
})
app.post("/order_room", (req,res)=>{
    console.log(req.body)
    let object = req.body
    let neworder = orderModel(object)
    neworder.save();
    res.redirect("/")
})

app.post("/login",(req,res)=>{
    if ((req.body.username=="admin")&&(req.body.password=="admin"))
    {
        res.cookie("admin",admincookie,{maxAge: 900000})
        res.redirect("/")
    }else      
        res.redirect("/login")
    console.log(req.body)
})
app.get("/user/:id",(req,res)=>{
    console.log(request.params)
    res.send("hello")
})
